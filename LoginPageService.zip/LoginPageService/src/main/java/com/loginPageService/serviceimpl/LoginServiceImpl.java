package com.loginPageService.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.loginPageService.model.User;
import com.loginPageService.repository.LoginRepository;
import com.loginPageService.service.LoginService;

public class LoginServiceImpl implements LoginService{
	
	@Autowired
	LoginRepository loginRepository;

	@Override
	public int getLoginDetails(User user) {
		// TODO Auto-generated method stub
		List<User> users = loginRepository.findAll();
		
		for(User u : users) {
			if(u.getUsername().equals(user.getUsername()) && u.getPassword().equals(user.getPassword())) {
				if(u.getRole().equals("admin")) {
					return 1;
				} else {
					return 2;
				}
			}
		}
		return 0;
	}
}
