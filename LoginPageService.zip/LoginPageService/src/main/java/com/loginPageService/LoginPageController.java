package com.loginPageService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.loginPageService.model.User;
import com.loginPageService.serviceimpl.LoginServiceImpl;

@Controller
public class LoginPageController {
	
	LoginServiceImpl loginService = new LoginServiceImpl();
	
	@GetMapping("/login")
    public String loadForm(Model model) {
        model.addAttribute("login", new User());
        return "LoginPage";
    }
	
	@PostMapping(value="/login")
	@ResponseBody
    public String greetingSample(@ModelAttribute User user) {
		int roleChoice = loginService.getLoginDetails(user);
		if(roleChoice > 0) {
			if(roleChoice == 1) {
				return "Admin LoginSuccess";
			} else {
				return "User LoginSuccess";
			}
		}
		return "incorrect";
	}
		
}
