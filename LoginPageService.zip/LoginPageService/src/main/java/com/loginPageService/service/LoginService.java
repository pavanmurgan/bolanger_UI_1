package com.loginPageService.service;


import com.loginPageService.model.User;

public interface LoginService {
	public int getLoginDetails(User user);
}
