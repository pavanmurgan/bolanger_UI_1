package com.resourcetrackingmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmanagement.model.Technologies;

public interface TechnologiesRepository extends JpaRepository<Technologies, Long> {

}
