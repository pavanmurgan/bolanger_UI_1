package com.resourcetrackingmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmanagement.model.TempUsers;

public interface TempUsersRepository extends JpaRepository<TempUsers, Long> {

}
