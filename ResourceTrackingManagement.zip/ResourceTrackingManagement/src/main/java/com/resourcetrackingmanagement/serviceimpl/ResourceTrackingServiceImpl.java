package com.resourcetrackingmanagement.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.resourcetrackingmanagement.model.Groups;
import com.resourcetrackingmanagement.model.TaskList;
import com.resourcetrackingmanagement.model.Users;
import com.resourcetrackingmanagement.repository.GroupsRepository;
import com.resourcetrackingmanagement.repository.LogInTrackRepository;
import com.resourcetrackingmanagement.repository.RequestsRepository;
import com.resourcetrackingmanagement.repository.TaskListRepository;
import com.resourcetrackingmanagement.repository.TechnologiesRepository;
import com.resourcetrackingmanagement.repository.TempUsersRepository;
import com.resourcetrackingmanagement.repository.UserRepository;
import com.resourcetrackingmanagement.service.ResourceTrackingService;

@Service
@Transactional
public class ResourceTrackingServiceImpl implements ResourceTrackingService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	GroupsRepository groupsRepository;
	
	@Autowired
	TaskListRepository taskListRepository;

	@Autowired
	LogInTrackRepository logInTrackRepository;
	
	@Autowired
	RequestsRepository requestsRepository;
	
	@Autowired
	TechnologiesRepository technologiesRepository;
	
	@Autowired
	TempUsersRepository tempUsersRepository;
	
	@Override
	public void userRegistration(Users users) {
		users.setStatus("Inprogress");
		userRepository.save(users);
	}

	@Override
	public void createGroup(Groups groups) {
		groupsRepository.save(groups);
	}

	@Override
	public void createTaskGroup(TaskList taskList) {
		taskListRepository.save(taskList);
	}

	@Override
	public void approveUser(Users user, String role) {
		user.setPassword("Welcome@123");
		user.setRole(role);
		user.setStatus("Approved");
		userRepository.save(user);
	}
	

}
