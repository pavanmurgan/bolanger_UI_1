package com.resourcetrackingmanagement.service;

import com.resourcetrackingmanagement.model.Groups;
import com.resourcetrackingmanagement.model.TaskList;
import com.resourcetrackingmanagement.model.Users;

public interface ResourceTrackingService {
	public void userRegistration(Users users);
	public void createGroup(Groups groups);
	public void createTaskGroup(TaskList taskList);
	public void approveUser(Users users, String role);
}
