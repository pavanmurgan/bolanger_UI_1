package com.resourcetrackingmanagement;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.resourcetrackingmanagement.model.Groups;
import com.resourcetrackingmanagement.model.Sample;
import com.resourcetrackingmanagement.model.TaskList;
import com.resourcetrackingmanagement.model.Users;
import com.resourcetrackingmanagement.service.ResourceTrackingService;

@Controller
public class ResourceTrackingController {

	@Autowired
	ResourceTrackingService resourceTrackingService;
	
	@GetMapping("/sample")
    public String greetingForm(Model model) {
        model.addAttribute("sample", new Sample());
        return "first";
    }
	
	@PostMapping(value= "/sample")
	@ResponseBody
	public String getsampledate(@ModelAttribute Sample sample) {
		System.out.println(sample.getVar1());
		System.out.println(sample.getVar2());
		return "Done";
	}
	
	@PostMapping(value = "/register")
	public void userRegistration(@RequestBody Users users) {
		System.out.println(users.getAge());
		resourceTrackingService.userRegistration(users);
	}
	
	@PostMapping(value = "/creategroup")
	public void createGroup(Groups groups) {
		resourceTrackingService.createGroup(groups);
	}
	
	@PostMapping(value = "/createtask")
	public void createTaskGroup(TaskList taskList) {
		taskList.setProgress("Started");
		resourceTrackingService.createTaskGroup(taskList);
	}
	
	
	@GetMapping(value = "/approveuser")
	public void approveUser(Users users, String email, String role) {
		List<Users> userList = new ArrayList<Users>();
		for(Users user : userList) {
			if(user.getEmail().equals(email)) {
				resourceTrackingService.approveUser(user, role);
			}
		}
	}
}
